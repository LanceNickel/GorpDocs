# Gorp - Simple Minecraft CLI tools.

Please refer to this site for documentation and installation instructions:

[Gorp Documentation](https://gorp.lanickel.com/)



## For help
Shoot me an email: gorp@lanickel.com

Or open an issue.



## License & Warranty
Gorp is licensed under the GNU GPL v3 license. The full license text is available in "COPYING".

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.